GenCollectionInterface README file
version 1.0
11/7/2009
RSA

The index.html in this directory contains the documentation.
This package contains the gCI tools and the output of a run
creating the web interface for the Internet Archive Children's Library.

It is also possible to create an attached storage interface for 
the IACL. Please refer to the index.html for instructions.